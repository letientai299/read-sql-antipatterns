-- START:select
SELECT * FROM Bugs WHERE bug_id = 3456;
-- END:select
-- START:update
UPDATE Bugs SET tag2 = 'performance' WHERE bug_id = 3456;
-- END:update

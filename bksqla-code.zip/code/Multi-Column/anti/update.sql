UPDATE Bugs SET tag2 = 'performance' WHERE bug_id = 3456;

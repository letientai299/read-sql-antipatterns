DELETE FROM Screenshots WHERE bug_id = 1234 and image_id = 1;

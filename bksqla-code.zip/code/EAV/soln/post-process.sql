SELECT issue_id, attr_name, attr_value
FROM IssueAttributes
WHERE issue_id = 1234;

INSERT INTO FeatureRequests (issue_id, severity) VALUES ( ... ); -- ERROR!

INSERT INTO Issues (date_reported) VALUES ('banana'); -- ERROR!

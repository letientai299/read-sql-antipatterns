SELECT issue_id, date_reported FROM Issues;

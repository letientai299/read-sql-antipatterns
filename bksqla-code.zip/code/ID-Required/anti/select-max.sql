SELECT MAX(bug_id) + 1 AS next_bug_id FROM Bugs;

UPDATE BugStatus SET active = 'INACTIVE' WHERE status = 'DUPLICATE';

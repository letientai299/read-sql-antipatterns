SELECT status FROM BugStatus ORDER BY status;

SELECT status FROM BugStatus WHERE active = 'ACTIVE';

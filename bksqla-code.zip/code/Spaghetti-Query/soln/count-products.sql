SELECT COUNT(*) AS how_many_products
FROM Products;

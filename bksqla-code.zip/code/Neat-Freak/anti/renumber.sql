UPDATE Bugs SET bug_id = 3 WHERE bug_id = 4;

ALTER TABLE Bugs DROP COLUMN verified_by;

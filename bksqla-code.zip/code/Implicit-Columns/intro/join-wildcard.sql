SELECT * FROM Books b JOIN Authors a ON (b.author_id = a.author_id);

SELECT date_reported, summary, description, resolution, status, priority
FROM Bugs;

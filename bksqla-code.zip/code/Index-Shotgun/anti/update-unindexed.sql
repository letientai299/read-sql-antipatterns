UPDATE Bugs SET status = 'OBSOLETE' WHERE date_reported < '2000-01-01';

UPDATE Bugs SET status = 'FIXED' WHERE bug_id = 1234;

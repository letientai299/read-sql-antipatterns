SELECT * FROM Projects WHERE project_name = 'O'Hare'

-- START:standard
SELECT * FROM Projects WHERE project_name = 'O''Hare'
-- END:standard
-- START:backslash
SELECT * FROM Projects WHERE project_name = 'O\'Hare'
-- END:backslash

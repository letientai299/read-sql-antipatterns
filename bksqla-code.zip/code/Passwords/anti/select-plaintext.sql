SELECT account_name, email, password
FROM Accounts
WHERE account_id = 123;

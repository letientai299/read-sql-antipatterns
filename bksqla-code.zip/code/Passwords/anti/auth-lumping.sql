SELECT * FROM Accounts
WHERE account_name = 'bill' AND password = 'opensesame';

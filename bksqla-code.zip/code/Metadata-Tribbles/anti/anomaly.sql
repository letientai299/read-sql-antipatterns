UPDATE Bugs_2010
SET date_reported = '2009-12-27'
WHERE bug_id = 1234;

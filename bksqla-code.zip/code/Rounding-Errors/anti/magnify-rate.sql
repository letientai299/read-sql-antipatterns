SELECT hourly_rate * 1000000000 FROM Accounts WHERE account_id = 123;

SELECT * FROM Accounts WHERE hourly_rate = 59.95;

SELECT hourly_rate FROM Accounts WHERE account_id = 123;

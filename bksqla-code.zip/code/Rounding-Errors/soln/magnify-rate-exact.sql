SELECT hourly_rate * 1000000000 FROM Accounts WHERE hourly_rate = 59.95;

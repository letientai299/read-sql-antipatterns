SELECT hourly_rate FROM Accounts WHERE hourly_rate = 59.95;

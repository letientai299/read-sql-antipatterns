SELECT * FROM Bugs ORDER BY date_reported;

SELECT * FROM Comments WHERE bug_id = 1234;

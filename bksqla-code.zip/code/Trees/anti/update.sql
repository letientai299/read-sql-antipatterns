UPDATE Comments SET parent_id = 3 WHERE comment_id = 6;

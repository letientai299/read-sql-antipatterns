SELECT *
FROM TreePaths
WHERE ancestor = 4 AND path_length = 1;

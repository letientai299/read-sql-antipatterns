DELETE FROM TreePaths WHERE descendant = 7;

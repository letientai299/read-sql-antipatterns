UPDATE Bugs SET status = DEFAULT WHERE status = 'BANANA';

UPDATE Products
SET account_id = account_id || ',' || 56
WHERE product_id = 123;

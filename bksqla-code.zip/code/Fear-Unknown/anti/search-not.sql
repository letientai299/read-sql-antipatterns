SELECT * FROM Bugs WHERE NOT (assigned_to = 123);

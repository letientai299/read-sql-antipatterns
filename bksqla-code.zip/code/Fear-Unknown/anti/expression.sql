SELECT hours + 10 FROM Bugs;

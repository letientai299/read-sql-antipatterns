SELECT * FROM Bugs WHERE assigned_to = 123;

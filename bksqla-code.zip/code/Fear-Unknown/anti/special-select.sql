SELECT AVG( hours ) AS average_hours_per_bug FROM Bugs
WHERE hours <> -1;

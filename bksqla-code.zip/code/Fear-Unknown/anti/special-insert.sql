INSERT INTO Bugs (assigned_to, hours) VALUES (-1, -1);

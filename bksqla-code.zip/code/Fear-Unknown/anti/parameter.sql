SELECT * FROM Bugs WHERE assigned_to = ?;

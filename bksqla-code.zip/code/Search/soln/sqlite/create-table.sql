CREATE VIRTUAL TABLE BugsText USING fts3(summary, description);

SELECT * FROM BugsText WHERE BugsText MATCH 'crash -save';

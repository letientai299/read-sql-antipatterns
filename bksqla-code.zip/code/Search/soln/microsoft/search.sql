SELECT * FROM Bugs WHERE CONTAINS(summary, '"crash"');

ALTER TABLE Bugs ADD FULLTEXT INDEX bugfts (summary, description);

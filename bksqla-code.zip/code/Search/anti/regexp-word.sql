SELECT * FROM Bugs WHERE description REGEXP '[[:<:]]one[[:>:]]';

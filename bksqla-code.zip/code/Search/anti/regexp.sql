SELECT * FROM Bugs WHERE description REGEXP 'crash';

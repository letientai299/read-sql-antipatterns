SELECT * FROM Bugs WHERE description LIKE '%one%'; 
